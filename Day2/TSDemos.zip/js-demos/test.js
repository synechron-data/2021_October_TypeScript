// function Display(data) {

// }

// var d = { a: 1, b: 0 };

// Display(d);
// Display(true);


// function Display(data) {
//     console.log(data);
// }

function Display({ a, b }) {
    console.log(a, b);
}

var d = { a: 1, b: 0, c: 10 };

Display(d);