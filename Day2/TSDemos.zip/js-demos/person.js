function Person(){

}

Person.prototype.getName = function(){

}

Person.location = "Pune";

var p1 = new Person();
p1.getName();
console.log(p1.location);