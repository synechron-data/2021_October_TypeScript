// In TypeScript, Rest and Spread can be used with Array and Object type

// ... on Left hand side of assignment (=) operator - Rest
// ... on Right hand side of assignment (=) operator - Spread

// In ECMAScript 2015 - We can use ... only on Array
// In ECMAScript 2018 - We can use ... on Array and Object both

// ----------------------------------------------------------------------------- Array Spread

// var numArr1 = [10, 20, 30, 40, [50, 60, 70]];

// // Reference Copy
// // var numArr2 = numArr1;

// // Shallow Copy
// var numArr2 = [...numArr1];

// // Deep Copy
// // var numArr2 = JSON.parse(JSON.stringify(numArr1));

// numArr2[0] = 1000;
// (numArr2[4] as number[])[0] = 5000;

// console.log("Array 1:", numArr1);
// console.log("Array 2:", numArr2);

// ----------------------------------------------------------------------------- Array with Rest

// var numArr1 = [10, 20, 30, 40, 50];

// // Destructuring
// // var [x, y] = numArr1;

// // Destructuring with Rest
// var [x, y, ...z] = numArr1;

// console.log("x = " + x);
// console.log("y = " + y);
// console.log("z = " + z);
// console.log(Array.isArray(z));

// [x, y] = [y, x];

// console.log("x = " + x);
// console.log("y = " + y);

// --------------------------------------------------------------------------- Object Spread

// var emp1 = { id: 1, name: "Manish", address: { city: "Pune" } };

// Reference Copy
// var emp2 = emp1;

// Shallow Copy
// var emp2 = { ...emp1 };

// // Deep Copy
// // var emp2 = JSON.parse(JSON.stringify(emp1));

// emp2.id = 100;
// emp2.address.city = "Mumbai";

// console.log("Employee 1 - ", emp1);
// console.log("Employee 2 - ", emp2);

// ----------------------------------------------------- Object Rest
var emp = { id: 1, ename: "Manish", city: "Pune", state: "MH", pin: 411021 };

// Destructuring
// var { id, ename } = emp;
// console.log("Id: ", id);
// console.log("Name: ", ename);

// Destructuring with Rest
var { id, ename, ...address } = emp;

console.log("Id: ", id);
console.log("Name: ", ename);
console.log("Address: ", address);
