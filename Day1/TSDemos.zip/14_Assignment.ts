// Create a function Reverse which can accept string or array of any 
// type and give the following output

console.log(Reverse("Manish"));                 // [ 'h', 's', 'i', 'n', 'a', 'M' ]
console.log(Reverse(["PQR", "XYZ", "ABC"]));    // [ 'ABC', 'XYZ', 'PQR' ]
console.log(Reverse([10, 20, 30, 40]));         // [ 40, 30, 20, 10 ]
// console.log(Reverse(10));                       // Compile time Error