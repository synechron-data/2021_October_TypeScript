"use strict";
var arr2;
arr2 = ["Manish", 1];
arr2 = ["Abhijeet", "Pune"];
arr2 = [10, 20, 30, 40, 50];
arr2 = [1, "Manish"];
arr2 = [1, "Abhijeet", "Pune", 411038];
var dataRow;
dataRow = [1, "Manish"];
function insert_tg(data) {
}
function insert(data) {
}
insert([1, "Manish"]);
