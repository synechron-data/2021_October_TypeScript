"use strict";
function hi() {
    var args = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
    }
    if (args.length === 0)
        console.log("Hi World!");
    else if (args.length === 1)
        console.log("Hi " + args[0]);
    else
        throw new Error("Invalid Number of Arguments");
}
hi();
hi("Synechron");
