"use strict";
var a;
var s;
var p;
a = new Array();
s = Symbol("Hello");
p = new Promise(function (resolve, reject) { });
