// function hello_js() {
//     console.log("Hello World!");
// }

// function hello_js(name) {
//     console.log("Hello, ", name);
// }

// hello_js();
// hello_js("Synechron");


function hello_js() {
    function m1() {
        console.log("Hello World!");
    }

    function m2(name) {
        console.log("Hello, ", name);
    }

    if(arguments.length === 0)
        m1();
    else if(arguments.length === 1)
        m2(arguments[0]);
    else
        throw new Error("Inavlid Number of Arguments Passed");
}

hello_js();
hello_js("Synechron");