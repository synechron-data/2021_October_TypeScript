console.log("Demo Three");

class Person {
    constructor(name) {
        if (typeof name == "string")
            this._name = name;
        else
            throw new TypeError("Invalid data passed");
    }

    getName() {
        return this._name.toUpperCase();
    }

    setName(value) {
        if (typeof value == "string")
            this._name = value;
        else
            throw new TypeError("Invalid data passed");
    }
}

var p1 = new Person("Manish");
console.log(p1.getName());
p1.setName("Abhijeet");
console.log(p1.getName());

var p2 = new Person("Subodh");
console.log(p2.getName());
p2.setName("Ramakant");
console.log(p2.getName());

console.log(p1._name);