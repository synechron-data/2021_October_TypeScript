console.log("Demo Four");
var PersonType = /** @class */ (function () {
    function PersonType(name) {
        this._name = name;
    }
    PersonType.prototype.getName = function () {
        return this._name.toUpperCase();
    };
    PersonType.prototype.setName = function (value) {
        this._name = value;
    };
    return PersonType;
}());
var pOne = new PersonType("Manish");
console.log(pOne.getName());
pOne.setName("Abhijeet");
console.log(pOne.getName());
var p2 = new PersonType("Subodh");
console.log(p2.getName());
p2.setName("Ramakant");
console.log(p2.getName());
// console.log(pOne._name);
// 136 Bytes
