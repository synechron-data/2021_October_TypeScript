console.log("Demo Two");

var Person = (function () {
    function Person(name) {
        if (typeof name == "string")
            this._name = name;
        else
            throw new TypeError("Invalid data passed");
    }

    Person.prototype.getName = function () {
        return this._name.toUpperCase();
    }

    Person.prototype.setName = function (value) {
        if (typeof value == "string")
            this._name = value;
        else
            throw new TypeError("Invalid data passed");
    }

    return Person;
})();

var p1 = new Person("Manish");
console.log(p1.getName());
p1.setName("Abhijeet");
console.log(p1.getName());

var p2 = new Person("Subodh");
console.log(p2.getName());
p2.setName("Ramakant");
console.log(p2.getName());

// 136 Bytes

// p2.hello();
// var p3 = new Person(10);
// console.log(p3.getName());

console.log(pOne._name);
