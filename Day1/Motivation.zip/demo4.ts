console.log("Demo Four");

class PersonType {
    private _name: string;

    constructor(name: string) {
        this._name = name;
    }

    getName() {
        return this._name.toUpperCase();
    }

    setName(value: string) {
        this._name = value;
    }
}

var pOne = new PersonType("Manish");
console.log(pOne.getName());
pOne.setName("Abhijeet");
console.log(pOne.getName());

var p2 = new PersonType("Subodh");
console.log(p2.getName());
p2.setName("Ramakant");
console.log(p2.getName());

// console.log(pOne._name);

// 136 Bytes