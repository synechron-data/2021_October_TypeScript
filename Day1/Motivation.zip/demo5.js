// function multiplyJS(obj) {
//     return obj.a * obj.b;
// }
// function multiply1JS({ a, b }) {
//     return a * b;
// }
// multiplyJS(10);
// type Shape = {
//     a: number,
//     b: number
// };
// function multiplyTS(obj: Shape) {
//     return obj.a * obj.b;
// }
// multiplyTS(10);
// multiplyTS({ a: "asdasd", b: true });
// multiplyTS({ a: 10 });
// multiplyTS({ a: 10, b: 30 });
var arr = [10, 20, 30, 40];
// ECMASCRIPT 2015
var result = arr.find(function (x) { return x === 10; });
console.log(result);
